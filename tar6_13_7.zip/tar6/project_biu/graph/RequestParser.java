package graph;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class RequestParser {

    public static RequestInfo parseRequest(BufferedReader reader) throws IOException {
        String requestLine;

        do {
            requestLine = reader.readLine();
        } while (requestLine != null && requestLine.trim().isEmpty());

        if (requestLine == null) {
            return null;
        }

        String[] requestParts = requestLine.split(" ");
        String method = requestParts[0];
        String uri = requestParts[1];

        String[] uriAndParams = uri.split("\\?");
        String path = uriAndParams[0];
        String[] uriSegments = path.startsWith("/") ? path.substring(1).split("/") : path.split("/");

        Map<String, String> parameters = new HashMap<>();
        if (uriAndParams.length > 1) {
            for (String param : uriAndParams[1].split("&")) {
                String[] kv = param.split("=", 2);
                if (kv.length == 2) {
                    parameters.put(kv[0], kv[1]);
                }
            }
        }

        int contentLength = 0;
        String line;
        while ((line = reader.readLine()) != null && !line.isEmpty()) {
            if (line.toLowerCase().startsWith("content-length:")) {
                contentLength = Integer.parseInt(line.substring("content-length:".length()).trim());
            }
        }

        StringBuilder paramBlock = new StringBuilder();
        while (reader.ready()) {
            int ch = reader.read();
            if (ch == -1) break;
            paramBlock.append((char) ch);
            if (paramBlock.length() >= 2 && paramBlock.toString().endsWith("\n\n")) break;
        }

        String[] paramLines = paramBlock.toString().split("\n");
        for (String paramLine : paramLines) {
            if (paramLine.trim().isEmpty()) break;
            if (paramLine.contains("=")) {
                String[] kv = paramLine.split("=", 2);
                if (kv.length == 2) {
                    parameters.put(kv[0].trim(), kv[1].trim());
                }
            }
        }

        StringBuilder contentBuilder = new StringBuilder();
        while (reader.ready()) {
            int ch = reader.read();
            if (ch == -1) break;
            contentBuilder.append((char) ch);
        }

        // ניקוי תווים לא תקניים
        String rawContent = contentBuilder.toString();
        StringBuilder cleaned = new StringBuilder();
        for (char c : rawContent.toCharArray()) {
            if (c != '\n' && c != '\r' && c != '\t') {
                cleaned.append(c);
            }
        }
        cleaned.append('\n');

        byte[] content = cleaned.toString().getBytes();

        return new RequestInfo(method, uri, uriSegments, parameters, content);
    }

    public static class RequestInfo {
        private final String httpCommand;
        private final String uri;
        private final String[] uriSegments;
        private final Map<String, String> parameters;
        private final byte[] content;

        public RequestInfo(String httpCommand, String uri, String[] uriSegments,
                           Map<String, String> parameters, byte[] content) {
            this.httpCommand = httpCommand;
            this.uri = uri;
            this.uriSegments = uriSegments;
            this.parameters = parameters;
            this.content = content;
        }

        public String getHttpCommand() { return httpCommand; }

        public String getUri() { return uri; }

        public String[] getUriSegments() { return uriSegments; }

        public Map<String, String> getParameters() { return parameters; }

        public byte[] getContent() { return content; }
    }
}
