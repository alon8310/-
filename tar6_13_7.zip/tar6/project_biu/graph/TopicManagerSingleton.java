package graph;

import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class TopicManagerSingleton {

    public static class TopicManager {
    	public synchronized Map<String, Topic> getTopicMap() {
    	    return topics;
    	}

        private static TopicManager instance = null;
        private final Map<String, Topic> topics = new HashMap<>();

        private TopicManager() {
        	
        }

        public static synchronized TopicManager getInstance() {
            if (instance == null) {
                instance = new TopicManager();
            }
            return instance;
        }

        public synchronized Topic getTopic(String name) {
            Topic topic = topics.get(name);
            if (topic == null) {
                topic = new Topic(name);
                topics.put(name, topic);
            }
            return topic;
        }

        public synchronized Collection<Topic> getTopics() {
            return topics.values();
        }

        public synchronized void clear() {
            topics.clear();
        }
    }

    public static TopicManager get() {
        return TopicManager.getInstance();
    }
}
