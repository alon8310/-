package graph;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

import graph.Agent;
import graph.Message;

/**
 * A decorator for Agent that applies the Active Object pattern.
 * It decouples the thread that receives messages from the thread that processes them.
 */
public class ParallelAgent implements Agent {

    private final Agent wrappedAgent;
    private final BlockingQueue<CallbackTask> queue;
    private final Thread workerThread;
    private volatile boolean running = true;

    // Internal final class to hold topic + message together
    private static final class CallbackTask {
        final String topic;
        final Message message;

        CallbackTask(String topic, Message message) {
            this.topic = topic;
            this.message = message;
        }
    }

    /**
     * Constructs a ParallelAgent that wraps the given agent,
     * and uses a bounded blocking queue of the given capacity.
     *
     * @param agent    the wrapped Agent
     * @param capacity the maximum number of messages to hold in the queue
     */
    public ParallelAgent(Agent agent, int capacity) {
        this.wrappedAgent = agent;
        this.queue = new ArrayBlockingQueue<>(capacity);

        this.workerThread = new Thread(() -> {
            while (running || !queue.isEmpty()) {
                try {
                    CallbackTask task = queue.poll(100, TimeUnit.MILLISECONDS);
                    if (task != null) {
                        wrappedAgent.callback(task.topic, task.message);
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        });

        this.workerThread.start();
    }

    @Override
    public String getName() {
        return wrappedAgent.getName();
    }

    @Override
    public void reset() {
        wrappedAgent.reset();
    }

    @Override
    public void callback(String topic, Message msg) {
        try {
            queue.put(new CallbackTask(topic, msg)); // Blocks if full
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    @Override
    public void close() {
        running = false;
        workerThread.interrupt(); // Wake up thread if blocked on poll
        try {
            workerThread.join(); // Ensure the thread has stopped
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        wrappedAgent.close();
    }
}
