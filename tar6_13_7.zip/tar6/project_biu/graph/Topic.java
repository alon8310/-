package graph;

import java.util.ArrayList;
import java.util.List;

public class Topic {
    public final String name;
    private final List<Agent> subs = new ArrayList<>();
    private final List<Agent> pubs = new ArrayList<>();
    private Message lastMessage; // ✅ שדה חדש

    Topic(String name) {
        this.name = name;
    }

    public void subscribe(Agent a) {
        if (!subs.contains(a)) {
            subs.add(a);
        }
    }

    public void unsubscribe(Agent a) {
        subs.remove(a);
    }

    public void publish(Message m) {
        lastMessage = m; // ✅ שמירת הודעה אחרונה
        for (Agent a : subs) {
            a.callback(this.name, m);
        }
    }

    public void addPublisher(Agent a) {
        if (!pubs.contains(a)) {
            pubs.add(a);
        }
    }

    public void removePublisher(Agent a) {
        pubs.remove(a);
    }

    public List<Agent> getSubscribers() {
        return new ArrayList<>(subs);
    }

    public List<Agent> getPublishers() {
        return new ArrayList<>(pubs);
    }

    public Message getLastMessage() {
        return lastMessage;
    }

	private String expression = null;

public void setExpression(String expr) {
    this.expression = expr;
}

public String getExpression() {
    return expression;
}


    
}
