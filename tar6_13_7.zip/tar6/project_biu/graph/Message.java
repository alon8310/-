package graph;

import java.util.Date;

public class Message {
    public Message(byte[] data, String asText, double asDouble, Date date) {
		super();
		this.data = data;
		this.asText = asText;
		this.asDouble = asDouble;
		this.date = date;
	}
	public final byte[] data;
    public final String asText;
    public final double asDouble;
    public final Date date;
    public Message(String text) {
        this(text.getBytes(), text, parseDoubleSafe(text), new Date());
    }

    private static double parseDoubleSafe(String text) {
        try {
            return Double.parseDouble(text);
        } catch (NumberFormatException e) {
            return Double.NaN;
        }
    }

    public String getAsText() {
        return asText;
    }

    public Message(double number) {
        this(Double.toString(number).getBytes(), Double.toString(number), number, new Date());
    }


}
