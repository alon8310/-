package graph;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

import graph.RequestParser.RequestInfo;

public class MyHTTPServer extends Thread implements HTTPServer {

    private final int port;
    private final int nThreads;
    private ServerSocket serverSocket;
    private final ExecutorService pool;
    private final Map<String, Map<String, Servlet>> servletMap = new HashMap<>();
    private volatile boolean running = true;

    public MyHTTPServer(int port, int nThreads) {
        this.port = port;
        this.nThreads = nThreads;
        this.pool = Executors.newFixedThreadPool(nThreads);
    }

    @Override
    public void addServlet(String httpCommand, String uri, Servlet servlet) {
        servletMap
            .computeIfAbsent(httpCommand.toUpperCase(), k -> new HashMap<>())
            .put(uri, servlet);
    }

    @Override
    public void removeServlet(String httpCommand, String uri) {
        Map<String, Servlet> innerMap = servletMap.get(httpCommand.toUpperCase());
        if (innerMap != null) {
            innerMap.remove(uri);
        }
    }

    @Override
    public void start() {
        super.start();
    }

    @Override
    public void run() {
        try {
            serverSocket = new ServerSocket(port);
            while (running) {
                try {
                    Socket clientSocket = serverSocket.accept();
                    pool.execute(() -> handleClient(clientSocket));
                } catch (IOException e) {
                    if (running) {
                        e.printStackTrace();
                    }
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to start server on port " + port, e);
        }
    }

    private void handleClient(Socket clientSocket) {
        try (
            BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            OutputStream out = clientSocket.getOutputStream()
        ) {
            RequestInfo requestInfo = RequestParser.parseRequest(reader);
            if (requestInfo == null) {
                return;
            }

            Servlet servlet = findServlet(requestInfo.getHttpCommand(), requestInfo.getUri());
            if (servlet != null) {
                servlet.handle(requestInfo, out);
            } else {
                out.write("HTTP/1.1 404 Not Found\r\n\r\n".getBytes());
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                clientSocket.close();
            } catch (IOException ignore) {}
        }
    }

    private Servlet findServlet(String command, String uri) {
        Map<String, Servlet> uriMap = servletMap.get(command.toUpperCase());
        if (uriMap == null) {
            return null;
        }

        Servlet bestMatch = null;
        int longestMatch = -1;

        for (String prefix : uriMap.keySet()) {
            if (uri.startsWith(prefix) && prefix.length() > longestMatch) {
                bestMatch = uriMap.get(prefix);
                longestMatch = prefix.length();
            }
        }

        return bestMatch;
    }

    @Override
    public void close() {
        running = false;
        pool.shutdown();
        try {
            if (serverSocket != null) {
                serverSocket.close();
            }
        } catch (IOException ignore) {}
    }
}
