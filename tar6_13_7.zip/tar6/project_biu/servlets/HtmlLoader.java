package servlets;

import servlets.Servlet;
import server.RequestParser;

import java.io.*;

/**
 * A servlet that serves static HTML files from a given folder.
 */
public class HtmlLoader implements Servlet {
    private final String folder;

    /**
     * Creates a new HtmlLoader that reads files from the given folder.
     *
     * @param folder The path to the folder containing HTML files
     */
    public HtmlLoader(String folder) {
        this.folder = folder;
    }

    /**
     * Handles the request by loading an HTML file from disk and sending it to the client.
     * If the file does not exist, returns a 404 error page.
     *
     * @param req The HTTP request info
     * @param out The output stream to write the response
     * @throws IOException If an error occurs while reading or writing
     */
    @Override
    public void handle(RequestParser.RequestInfo req, OutputStream out) throws IOException {
        String[] segments = req.uriSegments;
        String fileName = segments.length > 1 ? segments[1] : "index.html";

        File file = new File(folder, fileName);
        PrintWriter writer = new PrintWriter(out);

        if (!file.exists()) {
            writer.println("HTTP/1.1 404 Not Found");
            writer.println("Content-Type: text/html");
            writer.println();
            writer.println("<html><body><h1>404 Not Found</h1></body></html>");
            writer.flush();
            return;
        }

        writer.println("HTTP/1.1 200 OK");
        writer.println("Content-Type: text/html; charset=utf-8");
        writer.println();

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                writer.println(line);
            }
        }

        writer.flush();
    }

    /**
     * No cleanup is needed for this servlet.
     */
    @Override
    public void close() throws IOException {
        // Nothing to clean up
    }
}
