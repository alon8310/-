package servlets;

import configs.GenericConfig;
import configs.Graph;
import graph.Agent;
import graph.Message;
import graph.Topic;
import graph.TopicManagerSingleton;
import servlets.Servlet;
import server.RequestParser;
import views.HtmlGraphWriter;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A servlet that handles file uploads of configuration files (.conf),
 * loads the agents and topics from the file, and updates the graph view.
 *
 * <p>Expected to receive a multipart/form-data POST request containing the file.</p>
 */
public class ConfLoader implements Servlet {

    /**
     * Handles the uploaded configuration file, updates the system graph,
     * and returns an HTML page with the updated layout.
     *
     * @param ri The parsed HTTP request info
     * @param toClient The output stream to send the response
     * @throws IOException If an error occurs while reading or writing
     */
    @Override
    public void handle(RequestParser.RequestInfo ri, OutputStream toClient) throws IOException {
        String body = new String(ri.content, StandardCharsets.UTF_8);
        PrintWriter pw = new PrintWriter(toClient);

        // Extract filename
        Pattern filenamePattern = Pattern.compile("filename=\"([^\"]+)\"");
        Matcher filenameMatcher = filenamePattern.matcher(body);
        String filename = filenameMatcher.find() ? filenameMatcher.group(1) : "uploaded_config.conf";

        // Find boundary line in multipart form
        String boundary = null;
        BufferedReader reader = new BufferedReader(new StringReader(body));
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.startsWith("--")) {
                boundary = line.trim();
                break;
            }
        }

        // Read file content from form
        boolean startContent = false;
        StringBuilder fileContent = new StringBuilder();
        while ((line = reader.readLine()) != null) {
            if (line.isEmpty()) {
                startContent = true;
                continue;
            }
            if (startContent) {
                if (line.startsWith(boundary)) break;
                fileContent.append(line).append("\n");
            }
        }

        // Save file locally
        try (FileOutputStream fos = new FileOutputStream(filename)) {
            fos.write(fileContent.toString().getBytes(StandardCharsets.UTF_8));
        }

        try {
            // Load agents from config file
            GenericConfig config = new GenericConfig();
            config.setConfFile(filename);
            config.create();

            // Build graph and trigger agent callbacks for existing messages
            Graph graph = new Graph();
            graph.createFromTopics();

            for (Topic topic : TopicManagerSingleton.get().getTopics()) {
                Message msg = topic.getLastMessage();
                if (msg != null) {
                    for (Agent agent : topic.getSubscribers()) {
                        System.out.println("📣 Triggering callback: " + agent.getName() + " ← " + topic.name);
                        agent.callback(topic.name, msg);
                    }
                }
            }

            // Respond with HTML visualization
            pw.println("HTTP/1.1 200 OK");
            pw.println("Content-Type: text/html; charset=utf-8");
            pw.println();
            pw.println("<!DOCTYPE html>");
            pw.println("<html><head><meta charset='utf-8'><title>Graph View</title></head><body>");
            pw.println("<h2>Graph View</h2>");
            pw.println("<div style='margin: 10px;'>");

            String changeLayout = ri.getParameters().get("shuffle");
            if ("true".equals(changeLayout)) {
                HtmlGraphWriter.advanceLayoutMode();
            }

            for (String htmlLine : HtmlGraphWriter.getGraphOnlyDiv(graph)) {
                pw.println(htmlLine);
            }

            pw.println("</div></body></html>");
            pw.flush();

        } catch (Exception e) {
            pw.println("HTTP/1.1 500 Internal Server Error");
            pw.println("Content-Type: text/plain");
            pw.println();
            pw.println("Error: " + e.getMessage());
            pw.flush();
        }
    }

    /**
     * This servlet has no resources to close.
     */
    @Override
    public void close() {}
}
