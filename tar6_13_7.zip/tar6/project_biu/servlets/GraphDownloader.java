package servlets;

import configs.Graph;
import graph.Agent;
import graph.Message;
import graph.Topic;
import graph.TopicManagerSingleton;
import server.RequestParser;
import views.HtmlGraphWriter;

import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.IOException;

public class GraphDownloader implements Servlet {

    @Override
    public void handle(RequestParser.RequestInfo req, OutputStream out) throws IOException {
        Graph graph = new Graph();
        graph.createFromTopics();

        String filename = "graph_view.html";

        PrintWriter writer = new PrintWriter(out);
        writer.println("HTTP/1.1 200 OK");
        writer.println("Content-Type: text/html; charset=utf-8");
        writer.println("Content-Disposition: attachment; filename=\"" + filename + "\"");
        writer.println();

        writer.println("<!DOCTYPE html>");
        writer.println("<html><head><meta charset='utf-8'><title>Graph Export</title></head><body>");
        writer.println("<h2>Exported Graph</h2>");
        writer.println("<div style='margin: 10px;'>");

        for (String htmlLine : HtmlGraphWriter.getGraphOnlyDiv(graph)) {
            writer.println(htmlLine);
        }

        writer.println("</div></body></html>");
        writer.flush();
    }

    @Override
    public void close() throws IOException {}
}
