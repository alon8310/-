package servlets;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import server.RequestParser.RequestInfo;

public class PlusServlet implements Servlet {
    @Override
    public void handle(RequestInfo ri, OutputStream toClient) throws IOException {
        System.out.println("PlusServlet invoked");
        System.out.println("Params: " + ri.getParameters());

        int x = Integer.parseInt(ri.getParameters().get("x"));
        int y = Integer.parseInt(ri.getParameters().get("y"));
        int sum = x + y;

        PrintWriter out = new PrintWriter(toClient, true); // autoFlush = true
        out.print("HTTP/1.1 200 OK\r\n");
        out.print("Content-Type: text/plain\r\n");
        out.print("\r\n");
        out.print(sum);
        out.flush();
    }

    @Override
    public void close() {}
} 
