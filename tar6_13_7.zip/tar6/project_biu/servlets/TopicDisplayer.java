package servlets;

import graph.Topic;
import graph.TopicManagerSingleton;
import graph.Message;
import servlets.Servlet;
import server.RequestParser;

import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.Map;

/**
 * A servlet that displays all topics in an HTML table.
 * Also allows publishing a message to a specific topic using query parameters.
 */
public class TopicDisplayer implements Servlet {

    /**
     * Handles the request: publishes a message to a topic (if provided),
     * and returns an HTML page showing all topics and their latest messages.
     *
     * @param req The parsed HTTP request
     * @param out The output stream to write the HTML response
     * @throws IOException If an error occurs while writing to the client
     */
    @Override
    public void handle(RequestParser.RequestInfo req, OutputStream out) throws IOException {
        Map<String, String> params = req.getParameters();
        String topicName = params.get("topic");
        String messageText = params.get("message");

        if (topicName != null && messageText != null) {
            Topic topic = TopicManagerSingleton.get().getTopic(topicName);
            if (topic != null) {
                Message message = new Message(messageText);
                topic.publish(message);
            }
        }

        PrintWriter writer = new PrintWriter(out);
        writer.println("HTTP/1.1 200 OK");
        writer.println("Content-Type: text/html; charset=utf-8");
        writer.println();
        writer.println("<html><body>");
        writer.println("<h2>Topics Table</h2>");
        writer.println("""
                <style>
                  table {
                    border-collapse: collapse;
                    width: 100%;
                    font-size: 18px;
                    margin-top: 20px;
                  }
                  th, td {
                    border: 1px solid #444;
                    padding: 10px;
                    text-align: left;
                  }
                  th {
                    background-color: #f2f2f2;
                  }
                  tr:nth-child(even) {
                    background-color: #fafafa;
                  }
                </style>
                <table>
                  <tr><th>Topic</th><th>Last Message</th><th>Expression</th></tr>
                """);

        for (Map.Entry<String, Topic> entry : TopicManagerSingleton.get().getTopicMap().entrySet()) {
            String name = entry.getKey();
            Message lastMsg = entry.getValue().getLastMessage();
            String last = (lastMsg != null) ? lastMsg.getAsText() : "(no message)";
            String expr = entry.getValue().getExpression();
            if (expr == null) expr = "";
            writer.printf("<tr><td>%s</td><td>%s</td><td>%s</td></tr>%n", name, last, expr);
        }

        writer.println("</table>");
        writer.println("</body></html>");
        writer.flush();
    }

    /**
     * No cleanup needed for this servlet.
     */
    @Override
    public void close() throws IOException {}
}
