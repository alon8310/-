package views;

import configs.Graph;
import configs.Node;
import graph.Message;
import graph.Topic;
import graph.TopicManagerSingleton;

import java.util.*;

public class HtmlGraphWriter {

    private static int layoutMode = 0;

    public static List<String> getGraphOnlyDiv(Graph g) {
        layoutMode = (layoutMode + 1) % 3;
        return getGraphOnlyDiv(g, layoutMode);
    }

    public static List<String> getGraphOnlyDiv(Graph g, int mode) {
        List<String> html = new ArrayList<>();

        html.add("<style>");
        html.add(".canvas { position: relative; width: 1800px; height: 1000px; border: 2px solid black; margin: 20px auto; background: #f9f9f9; overflow: visible; }");
        html.add(".node { position: absolute; text-align: center; padding: 15px; font-size: 18px; z-index: 15; }");
        html.add(".topic { width: 70px; height: 70px; background-color: #b0e57c; border-radius: 10px; border: 2px solid #333; }");
        html.add(".agent { width: 80px; height: 80px; background-color: #a0c4ff; border-radius: 50%; border: 2px solid #333; line-height: 80px; }");
        html.add("</style>");
        html.add("<div class='canvas'>");

        html.add("<svg width='1800' height='600' style='position:absolute; top:0; left:0; z-index:0'><defs>");
        html.add("<marker id='arrow' markerWidth='5' markerHeight='3' refX='10' refY='3.5' orient='auto' markerUnits='strokeWidth'>");
        html.add("<polygon points='0 0, 10 3.5, 0 7' fill='black' /></marker>");
        html.add("</defs>");

        Map<String, Integer[]> positions = new HashMap<>();
        List<Node> nodes = new ArrayList<>();
        g.forEach(nodes::add);
    	Collections.shuffle(nodes);


        if (mode == 0) {  // standard layout
            int topicX = 80, agentX = 80;
            int topicY = 80, agentY = 300;
            int topicStep = 140, agentStep = 180;

            for (Node node : nodes) {
                boolean isTopic = node.getName().startsWith("T");
                int x = isTopic ? topicX : agentX;
                int y = isTopic ? topicY : agentY;
                if (isTopic) topicX += topicStep;
                else agentX += agentStep;
                positions.put(node.getName(), new Integer[]{x, y});
            }
        } else if (mode == 1) {  // circle layout
            int centerX = 800, centerY = 350, radius = 250;
            for (int i = 0; i < nodes.size(); i++) {
                double angle = 2 * Math.PI * i / nodes.size();
                int x = (int) (centerX + radius * Math.cos(angle));
                int y = (int) (centerY + radius * Math.sin(angle));
                positions.put(nodes.get(i).getName(), new Integer[]{x, y});
            }
        } else {  // triangle layout with mixed topic/agent
           // nodes.sort((a, b) -> Boolean.compare(b.getName().startsWith("T"), a.getName().startsWith("T")));  if we want to sort the topics and agents
        	Collections.shuffle(nodes);

            int x = 100, y = 80, stepX = 140, stepY = 120;
            for (int i = 0; i < nodes.size(); i++) {
                positions.put(nodes.get(i).getName(), new Integer[]{x, y});
                x += stepX;
                if (i % 3 == 2) {
                    x = 100;
                    y += stepY;
                }
            }
        }

        for (Node from : g) {
            Integer[] fromPos = positions.get(from.getName());
            if (fromPos == null) continue;
            for (Node to : from.getEdges()) {
                Integer[] toPos = positions.get(to.getName());
                if (toPos == null) continue;
                int r = 30;
                int x1 = fromPos[0] + r;
                int y1 = fromPos[1] + r;
                int x2 = toPos[0] + r;
                int y2 = toPos[1] + r;
                boolean fromIsTopic = from.getName().startsWith("T");
                String color = fromIsTopic ? "red" : "black";
                html.add("<line x1='" + x1 + "' y1='" + y1 + "' x2='" + x2 + "' y2='" + y2 +
                        "' stroke='" + color + "' stroke-width='2' marker-end='url(#arrow)' />");
            }
        }

        html.add("</svg>");

        for (Node node : g) {
            String name = node.getName();
            Integer[] pos = positions.get(name);
            boolean isTopic = name.startsWith("T");
            String cssClass = isTopic ? "node topic" : "node agent";

            String display = name;
            if (isTopic) {
                String topicName = name.substring(1);
                Topic topic = TopicManagerSingleton.get().getTopic(topicName);
                Message msg = topic.getLastMessage();
                if (msg != null) {
                    String text = msg.getAsText();
                    if (text.matches("\\d+\\.0+")) text = text.replaceAll("\\.0+$", "");
                    display = "<div>" + topicName + "</div><div><b>" + text + "</b></div>";
                } else {
                    display = "<div>" + topicName + "</div>";
                }
            }

            html.add("<div class='" + cssClass + "' style='left:" + pos[0] + "px; top:" + pos[1] + "px;'>"
                    + display + "</div>");
        }

        html.add("</div>");
        return html;
    }

	public static void advanceLayoutMode() {
	    layoutMode = (layoutMode + 1) % 3;

		// TODO Auto-generated method stub
		
	}
}
