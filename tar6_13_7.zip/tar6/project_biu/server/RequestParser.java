package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * A helper class that parses an HTTP request from a BufferedReader.
 */
public class RequestParser {

    /**
     * Parses the request line, headers, parameters, and body content.
     *
     * @param reader The input stream from the client
     * @return A RequestInfo object with all the extracted fields, or null if no request found
     * @throws IOException If an I/O error occurs while reading
     */
    public static RequestInfo parseRequest(BufferedReader reader) throws IOException {
        String requestLine;
        do {
            requestLine = reader.readLine();
        } while (requestLine != null && requestLine.trim().isEmpty());

        if (requestLine == null) return null;

        String[] requestParts = requestLine.split(" ");
        String method = requestParts[0];
        String uri = requestParts[1];

        // Parse URI and query parameters
        String[] uriAndParams = uri.split("\\?");
        String path = uriAndParams[0];
        String[] uriSegments = path.startsWith("/") ? path.substring(1).split("/") : path.split("/");

        Map<String, String> parameters = new HashMap<>();
        if (uriAndParams.length > 1) {
            for (String param : uriAndParams[1].split("&")) {
                String[] kv = param.split("=", 2);
                if (kv.length == 2) parameters.put(kv[0], kv[1]);
            }
        }

        // Read headers
        Map<String, String> headers = new HashMap<>();
        int contentLength = 0;
        String line;
        while ((line = reader.readLine()) != null && !line.isEmpty()) {
            int colon = line.indexOf(":");
            if (colon != -1) {
                String key = line.substring(0, colon).trim();
                String value = line.substring(colon + 1).trim();
                headers.put(key, value);
                if (key.equalsIgnoreCase("Content-Length")) {
                    try {
                        contentLength = Integer.parseInt(value);
                    } catch (NumberFormatException ignored) {}
                }
            }
        }

        // Read body content
        char[] contentChars = new char[contentLength];
        int read = reader.read(contentChars);
        String rawContent = new String(contentChars, 0, read > 0 ? read : 0);
        byte[] content = rawContent.getBytes();

        return new RequestInfo(method, uri, uriSegments, parameters, content, headers);
    }

    /**
     * A data class that holds the parsed HTTP request fields.
     */
    public static class RequestInfo {
        private final String httpCommand;
        private final String uri;
        public final String[] uriSegments;
        private final Map<String, String> parameters;
        public final byte[] content;
        private final Map<String, String> headers;

        /**
         * Creates a new RequestInfo object.
         *
         * @param httpCommand The HTTP method (e.g. GET, POST)
         * @param uri The full requested URI
         * @param uriSegments The URI split into path parts
         * @param parameters Query string parameters
         * @param content The body of the request as bytes
         * @param headers The request headers
         */
        public RequestInfo(String httpCommand, String uri, String[] uriSegments,
                           Map<String, String> parameters, byte[] content, Map<String, String> headers) {
            this.httpCommand = httpCommand;
            this.uri = uri;
            this.uriSegments = uriSegments;
            this.parameters = parameters;
            this.content = content;
            this.headers = headers;
        }

        public String getHttpCommand() { return httpCommand; }
        public String getUri() { return uri; }
        public String[] getUriSegments() { return uriSegments; }
        public Map<String, String> getParameters() { return parameters; }
        public byte[] getContent() { return content; }
        public Map<String, String> getHeaders() { return headers; }
    }
}
