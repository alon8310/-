package server;

import servlets.Servlet;

/**
 * A basic interface for an HTTP server that supports adding and removing servlets,
 * and starting or stopping the server.
 */
public interface HTTPServer extends Runnable {

    /**
     * Adds a servlet that will handle requests matching the given HTTP command and URI prefix.
     *
     * @param httpCommanmd The HTTP method (e.g., "GET", "POST")
     * @param uri The URI prefix to match (e.g., "/calc")
     * @param s The servlet to handle matching requests
     */
    void addServlet(String httpCommanmd, String uri, Servlet s);

    /**
     * Removes a previously added servlet for the given HTTP method and URI prefix.
     *
     * @param httpCommanmd The HTTP method
     * @param uri The URI prefix
     */
    void removeServlet(String httpCommanmd, String uri);

    /**
     * Starts the HTTP server (usually in a new thread).
     */
    void start();

    /**
     * Stops the server and releases resources.
     */
    void close();
}
