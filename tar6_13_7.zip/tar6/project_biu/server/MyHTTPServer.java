package server;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import servlets.Servlet;
import server.RequestParser.RequestInfo;
import server.RequestParser;

/**
 * A simple multithreaded HTTP server.
 * Supports adding servlets based on HTTP command and URI prefix.
 */
public class MyHTTPServer extends Thread implements HTTPServer {

    private final int port;
    private final int nThreads;
    private ServerSocket serverSocket;
    private final ExecutorService pool;
    private final Map<String, Map<String, Servlet>> servletMap = new HashMap<>();
    private volatile boolean running = true;

    /**
     * Creates a new HTTP server.
     * @param port Port number to listen on
     * @param nThreads Number of threads for handling requests
     */
    public MyHTTPServer(int port, int nThreads) {
        this.port = port;
        this.nThreads = nThreads;
        this.pool = Executors.newFixedThreadPool(nThreads);
    }

    /**
     * Adds a servlet for a specific HTTP command and URI prefix.
     */
    @Override
    public void addServlet(String httpCommand, String uri, Servlet s) {
        servletMap
            .computeIfAbsent(httpCommand.toUpperCase(), k -> new HashMap<>())
            .put(uri, s);
    }

    /**
     * Removes a servlet for a specific HTTP command and URI prefix.
     */
    @Override
    public void removeServlet(String httpCommand, String uri) {
        Map<String, Servlet> inner = servletMap.get(httpCommand.toUpperCase());
        if (inner != null) {
            inner.remove(uri);
        }
    }

    /**
     * Starts the server in a new thread.
     */
    @Override
    public void start() {
        super.start();
    }

    /**
     * Main server loop that accepts connections and handles clients.
     */
    @Override
    public void run() {
        try {
            serverSocket = new ServerSocket(port);
            while (running) {
                try {
                    Socket clientSocket = serverSocket.accept();
                    pool.execute(() -> handleClient(clientSocket));
                } catch (IOException e) {
                    if (running) e.printStackTrace();
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to start server on port " + port, e);
        }
    }

    /**
     * Handles a single client connection.
     */
    private void handleClient(Socket clientSocket) {
        try (
            BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            OutputStream out = clientSocket.getOutputStream()
        ) {
            RequestInfo ri = RequestParser.parseRequest(reader);
            if (ri == null) return;

            Servlet servlet = findServlet(ri.getHttpCommand(), ri.getUri());
            if (servlet != null) {
                servlet.handle(ri, out);
            } else {
                out.write("HTTP/1.1 404 Not Found\r\n\r\n".getBytes());
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                clientSocket.close();
            } catch (IOException ignore) {}
        }
    }

    /**
     * Finds the best matching servlet using URI prefix.
     */
    private Servlet findServlet(String command, String uri) {
        Map<String, Servlet> uriMap = servletMap.get(command.toUpperCase());
        if (uriMap == null) return null;

        Servlet bestMatch = null;
        int longestMatch = -1;

        for (String prefix : uriMap.keySet()) {
            if (uri.startsWith(prefix) && prefix.length() > longestMatch) {
                bestMatch = uriMap.get(prefix);
                longestMatch = prefix.length();
            }
        }

        return bestMatch;
    }

    /**
     * Stops the server and shuts down the thread pool.
     */
    @Override
    public void close() {
        running = false;
        pool.shutdown();
        try {
            if (serverSocket != null) {
                serverSocket.close();
            }
        } catch (IOException ignore) {}
    }
}
