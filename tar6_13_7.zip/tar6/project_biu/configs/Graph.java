package configs;

import java.util.*;

import graph.Agent;
import graph.Topic;
import graph.TopicManagerSingleton;
import graph.TopicManagerSingleton.TopicManager;

public class Graph extends ArrayList<Node> {
    private static final long serialVersionUID = 1L;

    public boolean hasCycles() {
        Set<Node> visited = new HashSet<>();
        for (Node node : this) {
            if (!visited.contains(node)) {
                if (hasCyclesDFS(node, visited, new HashSet<>())) return true;
            }
        }
        return false;
    }

    private boolean hasCyclesDFS(Node node, Set<Node> visited, Set<Node> recStack) {
        if (recStack.contains(node)) return true;
        if (visited.contains(node)) return false;

        visited.add(node);
        recStack.add(node);

        for (Node neighbor : node.getEdges()) {
            if (hasCyclesDFS(neighbor, visited, recStack)) return true;
        }

        recStack.remove(node);
        return false;
    }

    public void createFromTopics() {
        this.clear();

        TopicManager tm = TopicManagerSingleton.get();
        Map<String, Node> nodeMap = new HashMap<>();

        for (Topic topic : tm.getTopics()) {
            String topicName = "T" + topic.name;
            Node topicNode = new Node(topicName);
            nodeMap.put(topicName, topicNode);
            this.add(topicNode);
            
        }

        Set<Agent> allAgents = new HashSet<>();
        for (Topic topic : tm.getTopics()) {
            allAgents.addAll(topic.getSubscribers());
            allAgents.addAll(topic.getPublishers());
        }

        for (Agent agent : allAgents) {
            String agentName = "A" + agent.getName();
            Node agentNode = new Node(agentName);
            nodeMap.put(agentName, agentNode);
            this.add(agentNode);
        }

        for (Topic topic : tm.getTopics()) {
            Node topicNode = nodeMap.get("T" + topic.name);
            for (Agent agent : topic.getSubscribers()) {
                Node agentNode = nodeMap.get("A" + agent.getName());
                topicNode.addEdge(agentNode);
            }
            for (Agent agent : topic.getPublishers()) {
                Node agentNode = nodeMap.get("A" + agent.getName());
                agentNode.addEdge(topicNode);
            }
        }
       

    }
}
