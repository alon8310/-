
package configs;

import java.io.*;
import java.util.*;

import graph.Agent;
import graph.ParallelAgent;
import graph.TopicManagerSingleton;

public class GenericConfig implements Config {
    private String confFilePath;
    private List<Agent> agents = new ArrayList<>();

    public void setConfFile(String path) {
        this.confFilePath = path;
    }

    @Override
    public void create() {
        if (confFilePath == null) {
            System.err.println("No configuration file path set.");
            return;
        }

        agents.clear(); // ✅ clear old agents before loading new ones
        int agentCounter = 0; // ✅ manual counter to avoid miscount due to exceptions

        List<String> lines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(confFilePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    lines.add(line.trim());
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading config file:");
            e.printStackTrace();
            return;
        }

        for (int i = 0; i < lines.size(); ) {
            String line = lines.get(i);
            if (line.startsWith("topic ")) {
                String topicName = line.substring(6).trim();
                TopicManagerSingleton.get().getTopic(topicName); // register topic
                i++;
            } else if (line.startsWith("agent ")) {
                if (i + 2 >= lines.size()) {
                    System.err.println("Invalid agent block starting at line: " + i);
                    break;
                }
                String className = line.substring(6).trim();

                String subsLine = lines.get(i + 1);
                String pubsLine = lines.get(i + 2);

                if (!subsLine.startsWith("subscribe ") || !pubsLine.startsWith("publish ")) {
                    System.err.println("Expected subscribe/publish lines after agent at line: " + i);
                    break;
                }

                String[] subs = subsLine.substring("subscribe ".length()).split(",");
                String[] pubs = pubsLine.substring("publish ".length()).split(",");
                i += 3;

                try {
                    Class<?> cls = Class.forName(className);
                    Agent baseAgent = (Agent) cls.getConstructor(String[].class, String[].class)
                            .newInstance((Object) subs, (Object) pubs);

                    final int currentId = agentCounter++;
                    ParallelAgent pa = new ParallelAgent(baseAgent, 1) {
                        @Override
                        public String getName() {
                            return baseAgent.getName();  // רק השם המקורי, בלי מזהה מספרי
                        }
                    };


                    for (String s : subs) {
                        TopicManagerSingleton.get().getTopic(s.trim()).subscribe(pa);
                    }
                    for (String p : pubs) {
                        TopicManagerSingleton.get().getTopic(p.trim()).addPublisher(pa);
                    }

                    agents.add(pa);
                } catch (Exception e) {
                    System.err.println("Failed to create agent: " + className);
                    e.printStackTrace();
                }
            } else {
                i++; // skip unknown lines
            }
        }
    }

    public List<Agent> getAgents() {
        return agents;
    }

    @Override
    public void close() {
        for (Agent agent : agents) {
            agent.close();
        }
    }

    @Override
    public String getName() {
        return "GenericConfig";
    }

    @Override
    public int getVersion() {
        return 1;
    }
}
