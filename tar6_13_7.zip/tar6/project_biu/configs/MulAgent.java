package configs;

import graph.Agent;
import graph.Message;
import graph.TopicManagerSingleton;

public class MulAgent implements Agent {
	   private double x = Double.NaN;
	    private double y = Double.NaN;
	    private final String[] pubs;
	    private final String topicX;
	    private final String topicY;

	    public MulAgent(String[] subs, String[] pubs) {
	        this.pubs = pubs;
	        this.topicX = subs[0];
	        this.topicY = subs[1];

	        TopicManagerSingleton.get().getTopic(topicX).subscribe(this);
	        TopicManagerSingleton.get().getTopic(topicY).subscribe(this);
	        TopicManagerSingleton.get().getTopic(pubs[0]).addPublisher(this);
	        TopicManagerSingleton.get().getTopic(pubs[0]).setExpression("(" + topicX + " * " + topicY + ")");

	    }

	    @Override
	    public String getName() {
	        return "MulAgent";
	    }

	    @Override
	    public void reset() {
	        x = Double.NaN;
	        y = Double.NaN;
	    }

	    @Override
	    public void callback(String topic, Message msg) {
	        if (topic.equals(topicX)) {
	            x = msg.asDouble;
	        } else if (topic.equals(topicY)) {
	            y = msg.asDouble;
	        }

	        if (!Double.isNaN(x) && !Double.isNaN(y)) {
	            double result = x * y;
	            TopicManagerSingleton.get().getTopic(pubs[0]).publish(new Message(result));
	        }
	    }

	    @Override
	    public void close() {}
	}
