package configs;

import java.util.function.BinaryOperator;

import graph.Agent;
import graph.Message;
import graph.TopicManagerSingleton;

public class BinOpAgent implements Agent {
    private final String name;
    private final String topic1;
    private final String topic2;
    private final String outputTopic;
    private final BinaryOperator<Double> operation;

    private Double val1 = null;
    private Double val2 = null;

    public BinOpAgent(String name, String topic1, String topic2, String outputTopic, BinaryOperator<Double> operation) {
        this.name = name;
        this.topic1 = topic1;
        this.topic2 = topic2;
        this.outputTopic = outputTopic;
        this.operation = operation;

        TopicManagerSingleton.get().getTopic(topic1).subscribe(this);
        TopicManagerSingleton.get().getTopic(topic2).subscribe(this);
        TopicManagerSingleton.get().getTopic(outputTopic).addPublisher(this);
    }

    public String getOutputTopic() {
        return outputTopic;
    }

    public String getName() {
        return name;
    }

    public void reset() {
        val1 = null;
        val2 = null;
    }

    public void callback(String topic, Message msg) {
        if (Double.isNaN(msg.asDouble)) return;

        if (topic.equals(topic1)) val1 = msg.asDouble;
        else if (topic.equals(topic2)) val2 = msg.asDouble;

        if (val1 != null && val2 != null) {
            double result = operation.apply(val1, val2);
            TopicManagerSingleton.get().getTopic(outputTopic).publish(new Message(result));
        }
    }

    public void close() {}
}
