
package configs;
import graph.Topic;
import graph.Agent;
import graph.Message;
import graph.TopicManagerSingleton;

public class IncAgent implements Agent {
    private final String sub;
    private final String[] pubs;

    public IncAgent(String[] subs, String[] pubs) {
        this.sub = subs[0];
        this.pubs = pubs;

        TopicManagerSingleton.get().getTopic(sub).subscribe(this);
        TopicManagerSingleton.get().getTopic(pubs[0]).addPublisher(this);
    }

    @Override
    public String getName() {
        return "IncAgent";
    }

    @Override
    public void reset() {}

    @Override
    public void callback(String topic, Message msg) {
        System.out.println("📥 IncAgent received message on topic: " + topic + " with value: " + msg.getAsText());

        double val = msg.asDouble;
        if (!Double.isNaN(val)) {
            double result = val + 1;
            Message out = new Message(result);
            TopicManagerSingleton.get().getTopic(pubs[0]).publish(out);
            System.out.println("📤 IncAgent published to " + pubs[0] + ": " + out.getAsText());
        } else {
            System.out.println("⚠️ IncAgent received non-numeric message.");
        }
    }

    @Override
    public void close() {}
}
