package configs;

import java.util.*;

import graph.Agent;
import graph.Message;

public class Node {
    private final String name;
    private final List<Node> edges = new ArrayList<>();
    private Message message;
    private Agent agent; // ✅ מאפשר HTML עיצוב מבוסס Agent

    public Node(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public List<Node> getEdges() {
        return edges;
    }

    public void addEdge(Node node) {
        edges.add(node);
    }

    public Message getMessage() {
        return message;
    }

    public void setMessage(Message message) {
        this.message = message;
    }

    public Agent getAgent() {
        return agent;
    }

    public void setAgent(Agent agent) {
        this.agent = agent;
    }

    public boolean hasCycles() {
        return hasCyclesUtil(new HashSet<>(), new HashSet<>());
    }

    private boolean hasCyclesUtil(Set<Node> visited, Set<Node> recStack) {
        if (recStack.contains(this)) return true;
        if (visited.contains(this)) return false;

        visited.add(this);
        recStack.add(this);

        for (Node neighbor : edges) {
            if (neighbor.hasCyclesUtil(visited, recStack)) return true;
        }

        recStack.remove(this);
        return false;
    }
}
