import server.HTTPServer;
import server.MyHTTPServer;
import servlets.ConfLoader;
import servlets.GraphDownloader;
import servlets.HtmlLoader;
import servlets.TopicDisplayer;

import java.io.InputStreamReader;
import java.io.BufferedReader;

public class Main {
    public static void main(String[] args) throws Exception {
        int port = 8080;
        HTTPServer server = new MyHTTPServer(port, 5);
        server.addServlet("GET", "/publish", new TopicDisplayer());
        server.addServlet("POST", "/upload", new ConfLoader());
        server.addServlet("GET", "/app/", new HtmlLoader("html_files"));
        server.addServlet("GET", "/download", new GraphDownloader());

        
        server.start();

        System.out.println("✅ Server started at: http://localhost:" + port + "/app/index.html");
        System.out.println("🔁 Press ENTER to stop the server...");
        

        new BufferedReader(new InputStreamReader(System.in)).readLine();

        server.close();
        System.out.println("🛑 Server stopped.");
    }
}
